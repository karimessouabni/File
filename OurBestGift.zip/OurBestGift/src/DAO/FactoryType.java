package DAO;

/**
 * @author Karim
 * Enumeration Java pour controler les type de factory
 */
public enum FactoryType {
	DAO_FACTORY, XML_DAO_Factory;
}